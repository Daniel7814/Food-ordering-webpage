### Steps To Run Application
### Open Two Terminal Windows,One For Client Another For Server
### Run the Command npm install in both windows i.e one in client folder and another in server folder
### Run the Command npm run in both windows client will automatically open Web Application in Default Browser
### Client will run on port 3000 where as server will run 3001
### After Opening Web App Click On Sign up or enter following detials in login (email: example@gmail.com password: password)
### All Products and User Detials are Stored in db.json in server folder
